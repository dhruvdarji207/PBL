# PromptWall — AI Database Security Guardrail

PromptWall is an enterprise security middleware/guardrail that protects database systems (MySQL & SQLite) when users interact with databases through AI-powered natural-language chat interfaces.

The system does **NOT** directly trust user prompts or LLM-generated SQL. Every request passes through multiple strict security layers before reaching the database.

---

## 1. System Architecture & Logical Flow

```text
User Request
     │
     ▼
Chat Interface (Streamlit)
     │
     ▼
Prompt Security Engine  ──[MALICIOUS]──► Safe Refusal ──┐
     │ (SAFE)                                           │
     ▼                                                  │
LLM Gateway (Gemini API) [SQL Generation Only - NO DB]  │
     │                                                  │
     ▼                                                  │
SQL Security Engine (AST Parsing via sqlglot)           │
     │                                                  │
     ▼                                                  │
RBAC + Row-Level Security (RLS) & Column Security       │
     │                                                  │
     ▼                                                  │
Risk Scoring Engine (0-100 Score)                       │
     │                                                  │
     ▼                                                  │
Policy Engine (SOLE Final Authority: ALLOW/BLOCK)      │
    / \                                                 │
[ALLOW] [BLOCK] ────────────────────────────────────────┤
  │       └─────────────────────────────────────────────┤
  ▼                                                     ▼
MySQL Database (Read-Only SELECT Connection)    Audit Logger (Always Runs - No Exceptions)
  │                                                     │
  └─────────────────────────────────────────────────────┴──► Dashboard (Streamlit + Plotly)
```

---

## 2. Non-Negotiable Security Invariants

1. **Zero LLM Database Access**: The Gemini LLM generates SQL text only. It has **NO** database credentials, **NO** DB connection, and cannot execute SQL.
2. **Untrusted LLM Output**: All generated SQL is treated as **UNTRUSTED INPUT** and subjected to AST parsing (`sqlglot`).
3. **Independent Authorization**: RBAC, Row-Level Security (RLS), and Column-Level Security (CLS) are enforced programmatically by PromptWall—never relying on LLM behavior.
4. **Single Decisive Authority**: The **Policy Engine** is the **ONLY** component authorized to make the final `ALLOW` or `BLOCK` decision.
5. **Fail-Closed & Read-Only**: Any security engine failure defaults to `BLOCK`. Allowed queries execute exclusively against a read-only database connection (`SELECT` only).
6. **Mandatory Audit Logging**: The Audit Logger **ALWAYS RUNS** for every request (both `ALLOW` and `BLOCK`), feeding the Plotly & Streamlit security monitoring dashboard.

---

## 3. Trust Boundaries

- **UNTRUSTED**: User prompt input, Gemini LLM generated SQL output.
- **SECURITY CONTROLLED**: Prompt Security Engine, SQL Security Engine, RBAC Engine, Row Security Engine, Risk Scoring Engine, Policy Engine.
- **PROTECTED RESOURCE**: MySQL Database (or SQLite demo instance).
- **AUDIT & SOC**: Audit Logger (`audit_log.jsonl`), Streamlit + Plotly SOC Dashboard.

---

## 4. Setup & Running Instructions

### Step 1: Install Dependencies
```bash
pip install -r requirements.txt
```

### Step 2: Configure Environment Variables
Copy `.env.example` to `.env`:
```bash
cp .env.example .env
```
Fill in your `GEMINI_API_KEY` (optional; built-in rule fallback works for offline testing).

### Step 3: Run Automated Security Test Suite
```bash
pytest
```

### Step 4: Launch Streamlit Chat Interface & SOC Dashboard
```bash
streamlit run app.py
```

---

## 5. MySQL Production Database Provisioning (Optional)

If running with a local MySQL service:
1. Run `database/schema.sql` to build tables.
2. Run `database/seed.sql` to populate synthetic data.
3. Run `database/permissions.sql` to create the read-only user `promptwall_readonly`.
4. Set `USE_SQLITE_FALLBACK=false` in `.env`.
