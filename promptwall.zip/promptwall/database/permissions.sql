-- Least-Privilege Read-Only User Provisioning Script for MySQL

-- Create read-only user
CREATE USER IF NOT EXISTS 'promptwall_readonly'@'localhost' IDENTIFIED BY 'readonly_password';
CREATE USER IF NOT EXISTS 'promptwall_readonly'@'%' IDENTIFIED BY 'readonly_password';

-- Grant SELECT privileges only on promptwall database tables
GRANT SELECT ON promptwall.students TO 'promptwall_readonly'@'localhost';
GRANT SELECT ON promptwall.courses TO 'promptwall_readonly'@'localhost';
GRANT SELECT ON promptwall.enrollments TO 'promptwall_readonly'@'localhost';
GRANT SELECT ON promptwall.users TO 'promptwall_readonly'@'localhost';

GRANT SELECT ON promptwall.students TO 'promptwall_readonly'@'%';
GRANT SELECT ON promptwall.courses TO 'promptwall_readonly'@'%';
GRANT SELECT ON promptwall.enrollments TO 'promptwall_readonly'@'%';
GRANT SELECT ON promptwall.users TO 'promptwall_readonly'@'%';

-- Ensure NO write/ddl/admin privileges are granted
REVOKE INSERT, UPDATE, DELETE, DROP, ALTER, TRUNCATE, CREATE, GRANT OPTION ON promptwall.* FROM 'promptwall_readonly'@'localhost';
REVOKE INSERT, UPDATE, DELETE, DROP, ALTER, TRUNCATE, CREATE, GRANT OPTION ON promptwall.* FROM 'promptwall_readonly'@'%';

FLUSH PRIVILEGES;
