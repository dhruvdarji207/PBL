-- Synthetic Seed Data for PromptWall Security Demonstration

USE promptwall;

-- Clean existing demo data
SET FOREIGN_KEY_CHECKS = 0;
TRUNCATE TABLE enrollments;
TRUNCATE TABLE courses;
TRUNCATE TABLE students;
TRUNCATE TABLE users;
SET FOREIGN_KEY_CHECKS = 1;

-- Users
INSERT INTO users (user_id, name, email, role, password_hash) VALUES
(101, 'Alice Smith', 'alice@edu.org', 'Student', '$2b$12$eWzK.fakehash101'),
(102, 'Bob Jones', 'bob@edu.org', 'Student', '$2b$12$eWzK.fakehash102'),
(201, 'Dr. John Doe', 'john@edu.org', 'Faculty', '$2b$12$eWzK.fakehash201'),
(999, 'System Admin', 'admin@edu.org', 'Admin', '$2b$12$eWzK.fakehash999');

-- Students
INSERT INTO students (student_id, user_id, name, department, semester, email, academic_info, internal_security_data) VALUES
(101, 101, 'Alice Smith', 'Computer Science', 4, 'alice@edu.org', 'GPA 3.9, Dean List', 'SEC_TOKEN_ALICE_99'),
(102, 102, 'Bob Jones', 'Electrical Eng', 3, 'bob@edu.org', 'GPA 3.4, Good Standing', 'SEC_TOKEN_BOB_88');

-- Courses
INSERT INTO courses (course_id, course_name, department) VALUES
(1, 'CS101 Introduction to Security', 'Computer Science'),
(2, 'CS202 Database Middleware Architecture', 'Computer Science'),
(3, 'EE201 Digital Circuit Analysis', 'Electrical Eng');

-- Enrollments
INSERT INTO enrollments (enrollment_id, student_id, course_id, grade) VALUES
(10, 101, 1, 'A'),
(11, 101, 2, 'A-'),
(12, 102, 3, 'B+');
