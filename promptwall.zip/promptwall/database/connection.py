import sqlite3
import os
import mysql.connector
from config.settings import DB_HOST, DB_PORT, DB_NAME, DB_USER, DB_PASSWORD, USE_SQLITE_FALLBACK

class DatabaseManager:
    """
    Manages connections to MySQL (production environment) or SQLite (demo/testing fallback).
    Enforces read-only database query execution.
    """
    def __init__(self):
        self.sqlite_db_path = "promptwall_demo.db"
        if USE_SQLITE_FALLBACK:
            self._init_sqlite_demo_db()

    def _init_sqlite_demo_db(self):
        conn = sqlite3.connect(self.sqlite_db_path)
        cur = conn.cursor()
        cur.executescript("""
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY,
                name TEXT,
                email TEXT,
                role TEXT,
                password_hash TEXT
            );

            CREATE TABLE IF NOT EXISTS students (
                student_id INTEGER PRIMARY KEY,
                user_id INTEGER,
                name TEXT,
                department TEXT,
                semester INTEGER,
                email TEXT,
                academic_info TEXT,
                internal_security_data TEXT
            );

            CREATE TABLE IF NOT EXISTS courses (
                course_id INTEGER PRIMARY KEY,
                course_name TEXT,
                department TEXT
            );

            CREATE TABLE IF NOT EXISTS enrollments (
                enrollment_id INTEGER PRIMARY KEY,
                student_id INTEGER,
                course_id INTEGER,
                grade TEXT
            );

            INSERT OR IGNORE INTO users VALUES (101, 'Alice Smith', 'alice@edu.org', 'Student', 'hash101');
            INSERT OR IGNORE INTO users VALUES (102, 'Bob Jones', 'bob@edu.org', 'Student', 'hash102');
            INSERT OR IGNORE INTO users VALUES (201, 'Dr. John Doe', 'john@edu.org', 'Faculty', 'hash201');
            INSERT OR IGNORE INTO users VALUES (999, 'System Admin', 'admin@edu.org', 'Admin', 'hash999');

            INSERT OR IGNORE INTO students VALUES (101, 101, 'Alice Smith', 'Computer Science', 4, 'alice@edu.org', 'GPA 3.9', 'TOKEN_A');
            INSERT OR IGNORE INTO students VALUES (102, 102, 'Bob Jones', 'Electrical Eng', 3, 'bob@edu.org', 'GPA 3.4', 'TOKEN_B');

            INSERT OR IGNORE INTO courses VALUES (1, 'CS101 Intro to Security', 'Computer Science');
            INSERT OR IGNORE INTO courses VALUES (2, 'CS202 Middleware Systems', 'Computer Science');
            INSERT OR IGNORE INTO courses VALUES (3, 'EE201 Circuits', 'Electrical Eng');

            INSERT OR IGNORE INTO enrollments VALUES (10, 101, 1, 'A');
            INSERT OR IGNORE INTO enrollments VALUES (11, 101, 2, 'A-');
            INSERT OR IGNORE INTO enrollments VALUES (12, 102, 3, 'B+');
        """)
        conn.commit()
        conn.close()

    def execute_read_only_query(self, sql: str):
        """
        Executes read-only query using fallback SQLite or MySQL read-only connection.
        """
        if USE_SQLITE_FALLBACK:
            conn = sqlite3.connect(self.sqlite_db_path)
            conn.row_factory = sqlite3.Row
            cur = conn.cursor()
            cur.execute(sql)
            rows = [dict(r) for r in cur.fetchall()]
            conn.close()
            return rows

        conn = mysql.connector.connect(
            host=DB_HOST,
            port=DB_PORT,
            user=DB_USER,
            password=DB_PASSWORD,
            database=DB_NAME
        )
        cur = conn.cursor(dictionary=True)
        cur.execute(sql)
        rows = cur.fetchall()
        conn.close()
        return rows
