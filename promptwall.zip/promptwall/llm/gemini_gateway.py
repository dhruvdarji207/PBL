import os
from models.schemas import UserContext

class GeminiGateway:
    """
    CRITICAL SECURITY RULE:
    The Gemini LLM CAN ONLY generate SQL text.
    It MUST NOT:
    - Connect to MySQL / Database.
    - Have database credentials.
    - Execute SQL.
    - Read database results.
    - Decide ALLOW/BLOCK.

    Visual Note: "SQL generation only — No DB access"
    Output is ALWAYS treated as UNTRUSTED INPUT.
    """
    def __init__(self, api_key: str = None):
        self.api_key = api_key or os.getenv("GEMINI_API_KEY")

    def generate_sql(self, prompt: str, user: UserContext) -> str:
        # Minimal database schema context passed to LLM
        schema_context = (
            "Database Schema:\n"
            "- students (student_id, user_id, name, department, semester, email, academic_info)\n"
            "- courses (course_id, course_name, department)\n"
            "- enrollments (enrollment_id, student_id, course_id, grade)\n"
            "- users (user_id, name, email, role)\n"
        )
        
        prompt_lower = prompt.lower()

        # Rule-based fallback SQL synthesizer for test / offline / missing API key modes
        if not self.api_key or self.api_key == "your_gemini_api_key_here":
            if "ignore" in prompt_lower or "drop" in prompt_lower or "delete" in prompt_lower:
                return "DELETE FROM students;"
            if "password" in prompt_lower:
                return "SELECT name, password FROM users;"
            if "course" in prompt_lower:
                return f"SELECT c.course_name, e.grade FROM courses c JOIN enrollments e ON c.course_id = e.course_id WHERE e.student_id = {user.student_id or 101};"
            if "another student" in prompt_lower or "all student" in prompt_lower:
                return "SELECT * FROM students;"
            return f"SELECT student_id, name, department, semester FROM students WHERE student_id = {user.student_id or 101};"

        # Production Gemini API Call
        try:
            from google import genai
            client = genai.Client(api_key=self.api_key)
            full_prompt = (
                f"{schema_context}\n"
                f"Generate a single MySQL SELECT query for this request: '{prompt}'. "
                "Return ONLY the plain raw SQL query string without markdown fences."
            )
            response = client.models.generate_content(
                model="gemini-2.5-flash",
                contents=full_prompt
            )
            raw_sql = response.text.strip().replace("```sql", "").replace("```", "").strip()
            return raw_sql
        except Exception:
            # Safe Fallback SQL generation if network or API fails
            return f"SELECT student_id, name, department FROM students WHERE student_id = {user.student_id or 101};"
