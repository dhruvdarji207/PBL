import json
import os
from models.schemas import AuditEvent

class AuditLogger:
    """
    MANDATORY SECURITY COMPONENT:
    "Always Runs — No Exceptions"
    
    Every request MUST generate an audit event (both ALLOW and BLOCK execution paths).
    Stores structured event telemetry to JSONL and persistent audit storage.
    """
    def __init__(self, log_file: str = "audit_log.jsonl"):
        self.log_file = log_file

    def log_event(self, event: AuditEvent):
        event_dict = event.model_dump()
        with open(self.log_file, "a", encoding="utf-8") as f:
            f.write(json.dumps(event_dict) + "\n")
        return event.event_id

    def get_logs(self):
        if not os.path.exists(self.log_file):
            return []
        logs = []
        with open(self.log_file, "r", encoding="utf-8") as f:
            for line in f:
                if line.strip():
                    try:
                        logs.append(json.loads(line.strip()))
                    except Exception:
                        pass
        return logs
