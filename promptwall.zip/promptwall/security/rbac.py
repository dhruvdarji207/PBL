from config.policies import ROLE_TABLE_PERMISSIONS, BLOCKED_COLUMNS
from models.schemas import UserContext, SQLValidationResult, RBACResult

class RBACEngine:
    """
    Enforces Role-Based Access Control (RBAC) and Column-Level Security (CLS).
    Checks tables and columns against user role permissions matrix independently of LLM.
    """
    def check_authorization(self, user: UserContext, sql_val: SQLValidationResult) -> RBACResult:
        allowed_tables = ROLE_TABLE_PERMISSIONS.get(user.role, [])
        blocked_cols = BLOCKED_COLUMNS.get(user.role, [])

        unauth_tables = [t for t in sql_val.tables if t not in allowed_tables]
        unauth_cols = [c for c in sql_val.columns if c in blocked_cols]

        is_auth = len(unauth_tables) == 0 and len(unauth_cols) == 0
        reasons = []
        if unauth_tables:
            reasons.append(f"Unauthorized table access for role {user.role}: {unauth_tables}")
        if unauth_cols:
            reasons.append(f"Unauthorized column access for role {user.role}: {unauth_cols}")

        return RBACResult(
            is_authorized=is_auth,
            unauthorized_tables=unauth_tables,
            unauthorized_columns=unauth_cols,
            reason="; ".join(reasons) if reasons else "RBAC check passed."
        )
