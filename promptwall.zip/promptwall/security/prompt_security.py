import re
from models.schemas import PromptSecurityResult

class PromptSecurityEngine:
    """
    Detects malicious natural-language input before SQL generation.
    Checks for prompt injection, jailbreaks, system prompt leakage,
    schema discovery, admin impersonation, and policy bypass attempts.
    """
    INJECTION_PATTERNS = [
        (r"ignore (all )?previous instructions", "PROMPT_INJECTION", 0.95),
        (r"show (me )?the system prompt", "SYSTEM_PROMPT_LEAKAGE", 0.95),
        (r"reveal (the )?system prompt", "SYSTEM_PROMPT_LEAKAGE", 0.95),
        (r"ignore (all )?security rules", "JAILBREAK_ATTEMPT", 0.95),
        (r"pretend i am (an )?admin", "PRIVILEGE_ESCALATION", 0.90),
        (r"give me all users and passwords", "UNAUTHORIZED_DATA_ACCESS", 0.95),
        (r"bypass (the )?access control", "POLICY_BYPASS", 0.95),
        (r"show (me )?the database schema", "SCHEMA_DISCOVERY", 0.85),
        (r"list all (tables|columns|databases)", "SCHEMA_DISCOVERY", 0.85),
        (r"drop table|delete from|truncate table", "DANGEROUS_SQL_INJECTION", 0.99),
        (r"information_schema|sys\.tables|sqlite_master", "SCHEMA_DISCOVERY", 0.90),
        (r"union select|sleep\(|benchmark\(", "SQL_EXPLOIT_PATTERN", 0.95),
    ]

    def analyze_prompt(self, prompt: str) -> PromptSecurityResult:
        lowered = prompt.lower()
        for pattern, category, confidence in self.INJECTION_PATTERNS:
            if re.search(pattern, lowered):
                return PromptSecurityResult(
                    is_malicious=True,
                    category=category,
                    confidence=confidence,
                    reason=f"Matched malicious prompt pattern [{category}]."
                )
        return PromptSecurityResult(
            is_malicious=False,
            category="SAFE",
            confidence=0.0,
            reason="Prompt passed prompt security analysis."
        )
