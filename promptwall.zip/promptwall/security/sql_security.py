import sqlglot
import sqlglot.expressions as exp
from models.schemas import SQLValidationResult

class SQLSecurityEngine:
    """
    Parses and validates LLM-generated SQL queries using AST parsing (sqlglot).
    Detects dangerous commands (INSERT, UPDATE, DELETE, DROP, ALTER, TRUNCATE, etc.),
    unauthorized table/column access, stacked queries, UNION attacks, and comments.
    """
    DANGEROUS_COMMANDS = {"INSERT", "UPDATE", "DELETE", "DROP", "ALTER", "TRUNCATE", "CREATE", "GRANT", "REVOKE"}

    def validate_sql(self, sql_text: str) -> SQLValidationResult:
        flags = []
        if ";" in sql_text.rstrip(";"):
            flags.append("MULTIPLE_STATEMENTS_DETECTED")
        if "--" in sql_text or "/*" in sql_text:
            flags.append("SQL_COMMENT_BYPASS_ATTEMPT")

        try:
            parsed_list = sqlglot.parse(sql_text, read="mysql")
            if not parsed_list or len(parsed_list) > 1:
                flags.append("MULTIPLE_OR_INVALID_STATEMENTS")

            expression = parsed_list[0] if parsed_list else None
            if expression is None:
                return SQLValidationResult(
                    sql=sql_text,
                    command_type="UNKNOWN",
                    tables=[],
                    columns=[],
                    is_read_only=False,
                    is_valid=False,
                    security_flags=["INVALID_SQL_PARSE_FAILURE"]
                )

            command_type = expression.key.upper() if hasattr(expression, "key") else "UNKNOWN"
            is_read_only = command_type == "SELECT" and command_type not in self.DANGEROUS_COMMANDS

            if not is_read_only:
                flags.append(f"UNAUTHORIZED_COMMAND_{command_type}")

            tables = [table.name.lower() for table in expression.find_all(exp.Table)]
            columns = [column.name.lower() for column in expression.find_all(exp.Column)]

            if expression.find(exp.Union):
                flags.append("UNION_QUERY_DETECTED")

            return SQLValidationResult(
                sql=sql_text,
                command_type=command_type,
                tables=list(set(tables)),
                columns=list(set(columns)),
                is_read_only=is_read_only,
                is_valid=len(flags) == 0,
                security_flags=flags
            )
        except Exception as e:
            return SQLValidationResult(
                sql=sql_text,
                command_type="INVALID",
                tables=[],
                columns=[],
                is_read_only=False,
                is_valid=False,
                security_flags=[f"PARSER_ERROR: {str(e)}"]
            )
