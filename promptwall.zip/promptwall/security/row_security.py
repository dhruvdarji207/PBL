import sqlglot
from models.schemas import UserContext, SQLValidationResult, RowSecurityResult

class RowSecurityEngine:
    """
    Enforces Row-Level Security (RLS) constraints programmatically.
    Ensures users cannot view unauthorized rows (horizontal privilege escalation prevention).
    """
    def enforce_rls(self, user: UserContext, sql_val: SQLValidationResult) -> RowSecurityResult:
        if user.role != "Student":
            return RowSecurityResult(
                is_authorized=True,
                transformed_sql=sql_val.sql,
                applied_constraints=[],
                reason="Role does not require student-level RLS transformation."
            )

        student_id = user.student_id or 101
        try:
            parsed = sqlglot.parse_one(sql_val.sql, read="mysql")
            
            # Enforce student_id constraint on tables containing student records
            if "students" in sql_val.tables or "enrollments" in sql_val.tables:
                parsed = parsed.where(f"student_id = {student_id}")

            transformed = parsed.sql(dialect="mysql")
            return RowSecurityResult(
                is_authorized=True,
                transformed_sql=transformed,
                applied_constraints=[f"student_id = {student_id}"],
                reason=f"Applied Row-Level Security scope for Student ID {student_id}."
            )
        except Exception as e:
            return RowSecurityResult(
                is_authorized=False,
                transformed_sql=sql_val.sql,
                applied_constraints=[],
                reason=f"RLS Transformation failed: {str(e)}"
            )
