from models.schemas import PolicyDecisionResult, PromptSecurityResult, SQLValidationResult, RBACResult, RowSecurityResult, RiskScoreResult
from config.settings import BLOCK_RISK_THRESHOLD

class PolicyEngine:
    """
    CRITICAL ARCHITECTURAL REQUIREMENT:
    The Policy Engine is the ONLY component authorized to make the final ALLOW/BLOCK decision.
    No other component may independently authorize database execution.
    Fails closed on any security violation or error.
    """
    def evaluate(
        self,
        prompt_sec: PromptSecurityResult,
        sql_val: SQLValidationResult,
        rbac_res: RBACResult,
        rls_res: RowSecurityResult,
        risk_res: RiskScoreResult
    ) -> PolicyDecisionResult:
        
        # 1. Fail-closed on prompt security violation
        if prompt_sec and prompt_sec.is_malicious:
            return PolicyDecisionResult(
                decision="BLOCK",
                reason=f"Prompt Security Violation: {prompt_sec.reason}"
            )

        # 2. Fail-closed on missing or invalid SQL analysis
        if sql_val is None or not sql_val.is_valid or not sql_val.is_read_only:
            reason = "SQL Security Violation: Non-SELECT, invalid syntax, or missing parsing." if sql_val is None else f"SQL Security Violation: {sql_val.security_flags}"
            return PolicyDecisionResult(
                decision="BLOCK",
                reason=reason
            )

        # 3. Fail-closed on RBAC violation
        if rbac_res is None or not rbac_res.is_authorized:
            return PolicyDecisionResult(
                decision="BLOCK",
                reason=f"RBAC Violation: {rbac_res.reason if rbac_res else 'Missing RBAC context'}"
            )

        # 4. Fail-closed on RLS violation
        if rls_res is None or not rls_res.is_authorized:
            return PolicyDecisionResult(
                decision="BLOCK",
                reason=f"Row-Level Security Violation: {rls_res.reason if rls_res else 'Missing RLS context'}"
            )

        # 5. Fail-closed on risk score exceeding policy threshold
        if risk_res and risk_res.score >= BLOCK_RISK_THRESHOLD:
            return PolicyDecisionResult(
                decision="BLOCK",
                reason=f"Risk Score ({risk_res.score}) exceeded policy threshold ({BLOCK_RISK_THRESHOLD})."
            )

        # All checks passed
        return PolicyDecisionResult(
            decision="ALLOW",
            reason="All security guardrails passed."
        )
