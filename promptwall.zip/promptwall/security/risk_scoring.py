from models.schemas import PromptSecurityResult, SQLValidationResult, RBACResult, RowSecurityResult, RiskScoreResult

class RiskScoringEngine:
    """
    Calculates a multi-factor risk score (0-100) combining prompt injection,
    SQL security flags, RBAC violations, and RLS signals.
    Note: Risk Scoring Engine calculates risk but DOES NOT make final ALLOW/BLOCK decision.
    """
    def calculate_risk(
        self,
        prompt_sec: PromptSecurityResult,
        sql_val: SQLValidationResult,
        rbac_res: RBACResult,
        rls_res: RowSecurityResult
    ) -> RiskScoreResult:
        score = 0
        breakdown = {}

        if prompt_sec and prompt_sec.is_malicious:
            score += 80
            breakdown["prompt_injection"] = 80

        if sql_val:
            if not sql_val.is_read_only or not sql_val.is_valid:
                score += 50
                breakdown["sql_violation"] = 50

            if sql_val.security_flags:
                flag_score = len(sql_val.security_flags) * 20
                score += flag_score
                breakdown["security_flags"] = flag_score

        if rbac_res and not rbac_res.is_authorized:
            score += 40
            breakdown["rbac_violation"] = 40

        if rls_res and not rls_res.is_authorized:
            score += 40
            breakdown["rls_violation"] = 40

        score = min(100, score)

        if score <= 20:
            level = "Low"
        elif score <= 50:
            level = "Moderate"
        elif score <= 75:
            level = "High"
        else:
            level = "Critical"

        return RiskScoreResult(score=score, level=level, breakdown=breakdown)
