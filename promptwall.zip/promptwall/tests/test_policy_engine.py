import pytest
from models.schemas import PromptSecurityResult, SQLValidationResult, RBACResult, RowSecurityResult, RiskScoreResult
from security.policy_engine import PolicyEngine

@pytest.fixture
def engine():
    return PolicyEngine()

def test_policy_allow_safe_request(engine):
    p_sec = PromptSecurityResult(is_malicious=False, category="SAFE", confidence=0.0, reason="Safe")
    s_val = SQLValidationResult(sql="SELECT * FROM courses;", command_type="SELECT", tables=["courses"], columns=[], is_read_only=True, is_valid=True)
    rbac = RBACResult(is_authorized=True, unauthorized_tables=[], unauthorized_columns=[], reason="OK")
    rls = RowSecurityResult(is_authorized=True, transformed_sql="SELECT * FROM courses;", applied_constraints=[], reason="OK")
    risk = RiskScoreResult(score=0, level="Low", breakdown={})

    decision = engine.evaluate(p_sec, s_val, rbac, rls, risk)
    assert decision.decision == "ALLOW"

def test_policy_block_malicious_prompt(engine):
    p_sec = PromptSecurityResult(is_malicious=True, category="PROMPT_INJECTION", confidence=0.9, reason="Injection")
    decision = engine.evaluate(p_sec, None, None, None, None)
    assert decision.decision == "BLOCK"
