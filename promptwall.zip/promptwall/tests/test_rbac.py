import pytest
from models.schemas import UserContext, SQLValidationResult
from security.rbac import RBACEngine

@pytest.fixture
def engine():
    return RBACEngine()

def test_student_permitted_table(engine):
    user = UserContext(user_id=101, name="Alice", email="a@edu.org", role="Student", student_id=101)
    sql_val = SQLValidationResult(
        sql="SELECT * FROM students;", command_type="SELECT",
        tables=["students"], columns=["name"], is_read_only=True, is_valid=True
    )
    rbac = engine.check_authorization(user, sql_val)
    assert rbac.is_authorized is True

def test_student_blocked_column(engine):
    user = UserContext(user_id=101, name="Alice", email="a@edu.org", role="Student", student_id=101)
    sql_val = SQLValidationResult(
        sql="SELECT name, password FROM users;", command_type="SELECT",
        tables=["users"], columns=["name", "password"], is_read_only=True, is_valid=True
    )
    rbac = engine.check_authorization(user, sql_val)
    assert rbac.is_authorized is False
    assert "password" in rbac.unauthorized_columns
