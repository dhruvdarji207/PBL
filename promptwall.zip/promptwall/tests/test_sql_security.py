import pytest
from security.sql_security import SQLSecurityEngine

@pytest.fixture
def engine():
    return SQLSecurityEngine()

def test_valid_select_sql(engine):
    val = engine.validate_sql("SELECT name, department FROM students WHERE student_id = 101;")
    assert val.is_valid is True
    assert val.is_read_only is True
    assert val.command_type == "SELECT"
    assert "students" in val.tables

def test_reject_drop_table(engine):
    val = engine.validate_sql("DROP TABLE students;")
    assert val.is_read_only is False
    assert val.is_valid is False

def test_reject_delete(engine):
    val = engine.validate_sql("DELETE FROM students WHERE 1=1;")
    assert val.is_read_only is False
    assert val.is_valid is False

def test_reject_stacked_queries(engine):
    val = engine.validate_sql("SELECT * FROM students; DROP TABLE courses;")
    assert "MULTIPLE_STATEMENTS_DETECTED" in val.security_flags

def test_reject_union_attack(engine):
    val = engine.validate_sql("SELECT name FROM students UNION SELECT password_hash FROM users;")
    assert "UNION_QUERY_DETECTED" in val.security_flags
