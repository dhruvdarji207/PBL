import pytest
from models.schemas import PromptSecurityResult, SQLValidationResult, RBACResult, RowSecurityResult
from security.risk_scoring import RiskScoringEngine

@pytest.fixture
def engine():
    return RiskScoringEngine()

def test_low_risk_calculation(engine):
    p_sec = PromptSecurityResult(is_malicious=False, category="SAFE", confidence=0.0, reason="Safe")
    s_val = SQLValidationResult(sql="SELECT * FROM courses;", command_type="SELECT", tables=["courses"], columns=[], is_read_only=True, is_valid=True)
    rbac = RBACResult(is_authorized=True, unauthorized_tables=[], unauthorized_columns=[], reason="OK")
    rls = RowSecurityResult(is_authorized=True, transformed_sql="SELECT * FROM courses;", applied_constraints=[], reason="OK")

    risk = engine.calculate_risk(p_sec, s_val, rbac, rls)
    assert risk.score == 0
    assert risk.level == "Low"

def test_high_risk_on_injection(engine):
    p_sec = PromptSecurityResult(is_malicious=True, category="PROMPT_INJECTION", confidence=0.9, reason="Injection")
    risk = engine.calculate_risk(p_sec, None, None, None)
    assert risk.score >= 75
    assert risk.level in ["High", "Critical"]
