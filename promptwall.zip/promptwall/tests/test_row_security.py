import pytest
from models.schemas import UserContext, SQLValidationResult
from security.row_security import RowSecurityEngine

@pytest.fixture
def engine():
    return RowSecurityEngine()

def test_rls_applied_for_student(engine):
    user = UserContext(user_id=101, name="Alice", email="a@edu.org", role="Student", student_id=101)
    sql_val = SQLValidationResult(
        sql="SELECT name, department FROM students;", command_type="SELECT",
        tables=["students"], columns=["name", "department"], is_read_only=True, is_valid=True
    )
    rls = engine.enforce_rls(user, sql_val)
    assert rls.is_authorized is True
    assert "student_id = 101" in rls.transformed_sql.lower()

def test_rls_bypassed_for_faculty(engine):
    user = UserContext(user_id=201, name="Dr. John", email="j@edu.org", role="Faculty")
    sql_val = SQLValidationResult(
        sql="SELECT name FROM students;", command_type="SELECT",
        tables=["students"], columns=["name"], is_read_only=True, is_valid=True
    )
    rls = engine.enforce_rls(user, sql_val)
    assert rls.is_authorized is True
    assert rls.transformed_sql == sql_val.sql
