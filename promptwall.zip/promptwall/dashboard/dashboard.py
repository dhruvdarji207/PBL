import streamlit as st
import pandas as pd
import plotly.express as px

def render_soc_dashboard(audit_logger):
    """
    Streamlit + Plotly Security Operations Center (SOC) Dashboard.
    Visualizes metrics, decision distributions, risk breakdown, and live audit telemetry.
    """
    st.title("🛡️ PromptWall Security Operations Center (SOC)")
    st.caption("Real-Time Database Security Telemetry & Audit Analysis")

    logs = audit_logger.get_logs()
    if not logs:
        st.info("No audit events recorded yet. Perform queries in the chat interface to generate security telemetry.")
        return

    df = pd.DataFrame(logs)

    # Key Security Metrics Cards
    col1, col2, col3, col4 = st.columns(4)
    total_reqs = len(df)
    allowed_reqs = len(df[df['policy_decision'] == 'ALLOW'])
    blocked_reqs = len(df[df['policy_decision'] == 'BLOCK'])
    avg_risk = df['risk_score'].mean() if not df.empty else 0.0

    col1.metric("Total Requests", total_reqs)
    col2.metric("Allowed Requests", allowed_reqs, delta=f"{(allowed_reqs/total_reqs*100):.1f}%" if total_reqs else "0%")
    col3.metric("Blocked Requests", blocked_reqs, delta=f"{(blocked_reqs/total_reqs*100):.1f}%" if total_reqs else "0%", delta_color="inverse")
    col4.metric("Avg Risk Score", f"{avg_risk:.1f}/100")

    st.markdown("---")

    # Plotly Charts Layout
    chart_col1, chart_col2 = st.columns(2)

    with chart_col1:
        st.subheader("Policy Decision (ALLOW vs BLOCK)")
        fig_pie = px.pie(
            df, names='policy_decision', color='policy_decision',
            color_discrete_map={'ALLOW': '#00CC96', 'BLOCK': '#EF553B'},
            hole=0.4
        )
        st.plotly_chart(fig_pie, use_container_width=True)

    with chart_col2:
        st.subheader("Risk Score Distribution")
        fig_hist = px.histogram(
            df, x='risk_score', nbins=10, color='policy_decision',
            color_discrete_map={'ALLOW': '#00CC96', 'BLOCK': '#EF553B'},
            labels={'risk_score': 'Risk Score (0-100)'}
        )
        st.plotly_chart(fig_hist, use_container_width=True)

    st.subheader("Security Violations by Category")
    category_counts = df['security_category'].value_counts().reset_index()
    category_counts.columns = ['security_category', 'count']
    fig_bar = px.bar(
        category_counts, x='security_category', y='count',
        color='security_category',
        labels={'security_category': 'Security Category', 'count': 'Event Count'}
    )
    st.plotly_chart(fig_bar, use_container_width=True)

    st.markdown("---")
    st.subheader("Live Interactive Audit Table")
    
    # Filter Controls
    f_col1, f_col2 = st.columns(2)
    with f_col1:
        selected_role = st.multiselect("Filter by User Role", options=df['role'].unique(), default=df['role'].unique())
    with f_col2:
        selected_decision = st.multiselect("Filter by Decision", options=df['policy_decision'].unique(), default=df['policy_decision'].unique())

    filtered_df = df[(df['role'].isin(selected_role)) & (df['policy_decision'].isin(selected_decision))]

    display_cols = ['timestamp', 'role', 'prompt', 'risk_score', 'policy_decision', 'security_category', 'execution_status']
    st.dataframe(filtered_df[display_cols], use_container_width=True)
