import os
from dotenv import load_dotenv

# Load environment variables from .env if present
load_dotenv()

# Gemini API Credentials
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")

# MySQL Database Configuration
DB_HOST = os.getenv("DB_HOST", "localhost")
DB_PORT = int(os.getenv("DB_PORT", 3306))
DB_NAME = os.getenv("DB_NAME", "promptwall")
DB_USER = os.getenv("DB_USER", "promptwall_readonly")
DB_PASSWORD = os.getenv("DB_PASSWORD", "readonly_password")

# Fallback & Execution Mode
USE_SQLITE_FALLBACK = os.getenv("USE_SQLITE_FALLBACK", "true").lower() == "true"

# Safe User-Facing Refusal Message (Does not leak rules/internals)
SAFE_REFUSAL_MESSAGE = (
    "Sorry, I cannot process that request because it does not meet "
    "the system's security or authorization requirements."
)

# Risk Threshold Categories
RISK_THRESHOLDS = {
    "LOW": (0, 20),
    "MODERATE": (21, 50),
    "HIGH": (51, 75),
    "CRITICAL": (76, 100)
}

# Policy Engine Threshold for Mandatory Blocking
BLOCK_RISK_THRESHOLD = 50
