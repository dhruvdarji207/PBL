# Role-Based Table Access Control Matrix
ROLE_TABLE_PERMISSIONS = {
    "Student": ["students", "courses", "enrollments"],
    "Faculty": ["students", "courses", "enrollments", "users"],
    "Admin": ["students", "courses", "enrollments", "users", "audit_logs"]
}

# Column-Level Access Control Rules (Blocked sensitive columns per role)
BLOCKED_COLUMNS = {
    "Student": [
        "password",
        "password_hash",
        "internal_security_data",
        "admin_notes",
        "confidential_information"
    ],
    "Faculty": [
        "password",
        "password_hash",
        "internal_security_data"
    ],
    "Admin": [
        "password_hash"
    ]
}

# Strict Read-Only Allowed SQL Commands
ALLOWED_COMMANDS = ["SELECT"]
