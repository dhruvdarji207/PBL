from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
from datetime import datetime

class UserContext(BaseModel):
    user_id: int
    name: str
    email: str
    role: str  # Student, Faculty, Admin
    department: Optional[str] = None
    student_id: Optional[int] = None

class PromptSecurityResult(BaseModel):
    is_malicious: bool
    category: str
    confidence: float
    reason: str

class SQLValidationResult(BaseModel):
    sql: str
    command_type: str
    tables: List[str]
    columns: List[str]
    is_read_only: bool
    is_valid: bool
    security_flags: List[str] = Field(default_factory=list)

class RBACResult(BaseModel):
    is_authorized: bool
    unauthorized_tables: List[str] = Field(default_factory=list)
    unauthorized_columns: List[str] = Field(default_factory=list)
    reason: str

class RowSecurityResult(BaseModel):
    is_authorized: bool
    transformed_sql: str
    applied_constraints: List[str] = Field(default_factory=list)
    reason: str

class RiskScoreResult(BaseModel):
    score: int  # 0 - 100
    level: str  # Low, Moderate, High, Critical
    breakdown: Dict[str, int]

class PolicyDecisionResult(BaseModel):
    decision: str  # ALLOW or BLOCK
    reason: str
    timestamp: datetime = Field(default_factory=datetime.utcnow)

class AuditEvent(BaseModel):
    event_id: str
    timestamp: str
    user_id: int
    role: str
    prompt: str
    prompt_security_status: str
    generated_sql: Optional[str] = None
    final_sql: Optional[str] = None
    risk_score: int
    rbac_status: str
    row_security_status: str
    policy_decision: str
    execution_status: str
    security_category: str
    refusal_reason: Optional[str] = None
