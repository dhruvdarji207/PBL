def format_risk_badge(score: int) -> str:
    """Returns markdown badge string for risk level."""
    if score <= 20:
        return f"🟢 LOW RISK ({score}/100)"
    elif score <= 50:
        return f"🟡 MODERATE RISK ({score}/100)"
    elif score <= 75:
        return f"🟠 HIGH RISK ({score}/100)"
    else:
        return f"🔴 CRITICAL RISK ({score}/100)"
